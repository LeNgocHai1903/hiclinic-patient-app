export const SORT_BY_ALPHABET_INC = 'alphabet inc';
export const SORT_BY_ALPHABET_DECS = 'alphabet desc';
