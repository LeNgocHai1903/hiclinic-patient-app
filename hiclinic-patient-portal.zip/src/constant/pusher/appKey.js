export const APP_KEY = process.env.REACT_APP_PUSHER_KEY || process.env.PUSHER_KEY;
