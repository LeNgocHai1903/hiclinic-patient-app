export const BASE_URL = process.env.REACT_APP_PATIENT_SERVER_URL;
export const GET_ALL_CLINIC = `${process.env.REACT_APP_PATIENT_SERVER_URL}/profile/patient/clinics`;
